<?php
session_start();
require_once("dbconnect.php");

$temp = "reg";

if($_POST['reg_buttom']) 
{
    $fam = $_POST['fam'];
    $name = $_POST['name'];
    $login = $_POST['login'];
    $pass = $_POST['pass'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    
    $zapros = "SELECT login FROM user WHERE login = '".$login."'";
    $result = $mybase -> query($zapros);
    if($user_info = $result -> fetch_array())
    {
        $_SESSION['reg_mess'] = "Пользователь с таким логином уже существует!";
    }
    else
    {
        $zapros = "INSERT INTO user(admin, fam, name, login, pass, email, tel) VALUES('0','".$fam."','".$name."','".$login."','".$pass."','".$email."','".$tel."')";
        $result = $mybase -> query($zapros);
        if (!$result)
        {
            $_SESSION['reg_mess'] = "Упс... Произошла ошибка регистрации..";
        }
        else
        {
            $_SESSION['reg_mess'] = "";
            $_SESSION['login_mess'] = "Регистрация прошла успешно!";
            $temp = "login";
        }
    }
    
    header("Location: index.php?content=".$temp);
}
