<?php 
session_start();
require_once("dbconnect.php");
$_SESSION['uploads_dir'] = '/var/www/user3333/data/www/3333.vhost.domain.mousedc.ru/img/tovar';
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>MyRoom</title>

    <!-- Настройка viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS (Cloudflare CDN) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css" integrity="sha512-P5MgMn1jBN01asBgU0z60Qk4QxiXo86+wlFahKrsQf37c9cro517WzVSPPV1tDKzhku2iJ2FVgL67wG03SGnNA==" crossorigin="anonymous">

    <!-- jQuery (Cloudflare CDN) -->
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>

    <!-- Bootstrap Bundle JS (Cloudflare CDN) -->
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js" integrity="sha512-wV7Yj1alIZDqZFCUQJy85VN+qvEIly93fIQAN7iqDFCPEucLCeNFz4r35FCo9s6WrpdDQPi80xbljXB8Bjtvcg==" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="img/icons/logo.svg">
</head>

<body>
    <div id = "main-container">
        <div id = "left-menu">
            <a id = "logo" href="index.php">
                <img src="img/icons/logo.svg" alt="Логотип" height="75px">
                <span>MyRoom</span>
            </a>
            
            <div id = "kategory" class = "sticky-top">
                <span class = "big-text">Категории</span>
                
                <?php
                $zapros = "SELECT * FROM kategory";
                $result = $mybase -> query($zapros);
                
                while ($result_row = $result -> fetch_array()) 
                {
                    $class = ($result_row['id'] == $_GET['kat_id'])? "kategory-item medium-text active-btn" : "kategory-item medium-text";?>
                    <a class = "<?=$class?>" href="?content=katalog&kat_id=<?=$result_row['id']?>">
                        <div>
                            <?=$result_row['name'];?>
                        </div>
                    </a>
                <?php 
                }
                ?>
                
            </div>
        </div>

        <div id = "main-content">
            <?php
            if (isset($_GET['content']))
            {
                include($_GET['content'].'_page.php');
            }
            else
            {
                include('about_page.php');
            }
            ?>
        </div>
        
        <div id = "right-menu">
            <div class = "sticky-top">
                <a href="index.php?content=<?=($_SESSION['is_login'])? "user" : "profile"?>" title="Мой профиль">
                    <div class = "right-menu-item <?=(strpos("profile user reg login", $_GET['content']) !== false)? "active-btn":""?>">
                        <img src="img/icons/profile.svg" alt="Профиль" width="45px">
                    </div>
                </a>
                
                <a href="index.php?content=admin&action=add&object=tovar" title="Панель управления">
                    <div class = "right-menu-item <?=($_GET['content'] == "admin")? "active-btn":""?>" <?=($_SESSION['is_admin'] == true)? "":"hidden"?>>
                        <img src="img/icons/settings.svg" alt="Панель управления" width="45px">
                    </div>
                </a>

                <a href="index.php?content=korzina&section=buy" title="Моя корзина">
                    <div class = "right-menu-item <?=($_GET['content'] == "korzina")? "active-btn":""?>" <?=($_SESSION['is_login'] == true)? "":"hidden"?>>
                        <img src="img/icons/korzina.svg" alt="Корзина" width="45px">
                    </div>
                </a>

                <a href="index.php?content=katalog" title="Каталог товаров">
                    <div class = "right-menu-item <?=(strpos("katalog tovar", $_GET['content']) !== false)? "active-btn":""?>">
                        <img src="img/icons/catalogue.svg" alt="Каталог" width="45px">
                    </div>
                </a>
                
                <a href="exit.php" title="Покинуть профиль">
                    <div class = "right-menu-item" <?=($_SESSION['is_login'] == true)? "":"hidden"?>>
                        <img src="img/icons/exit.svg" alt="Выйти" width="45px">
                    </div>
                </a>
            </div>
            
            <a id = "up-btn" href="#">
                <div class = "right-menu-item" title = "К началу страницы">
                    <img src="img/icons/up.svg" alt="Профиль" width="35px">
                </div>
            </a>
        </div>
    </div>
</body>
</html>