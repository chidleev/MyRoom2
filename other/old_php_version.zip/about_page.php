<div id = "about-main-container">
    <div id = "about-text">
        <span id = "about-text-hello">Добро пожаловать!</span>
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">интернет-магазин мебели</span>
    </div>
    
    <span id = "about-text-help">Выберите категорию, чтобы увидеть товар</span>
</div>