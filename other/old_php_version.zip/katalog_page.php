<?php 
session_start();
?>
<div id = "katalog-main-container">
    <?php
    if (!isset($_GET['kat_id']))
    {
        $_SESSION['content'] = "katalog";
        $hidden = ($_GET['poisk'])? "" : "hidden";
    ?>
        <form id = "katalog-poisk" method="post" action="poisk_action.php">
            <input class="form-control" type="text" placeholder="Поиск товара по названию" name = "poisk" value="<?=$_GET['poisk']?>">
            <button class="my-btn" type="submit" name = "search">Искать</button>
            <button class="btn-clean" type="submit" name = "clean" <?=$hidden?>><img src="img/icons/trash.svg" alt="Очистить" width = "100%"></button>
        </form>
        
        <?php include('karusel.php');?>
        
    <?php
        if (!isset($_GET['poisk']))
        {
    ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Лучшие товары по мнению покупателей</span>
        </div>

        <div class = "tovar-container">
            <?php
            $zapros_tovar = "SELECT * FROM tovar ORDER BY rate desc LIMIT 4";
            $result_tovar = $mybase -> query($zapros_tovar);

            $i = 1;
            ?>
            <div class = "tovar-row">
                <?php
                while ($tovar = $result_tovar -> fetch_array()) 
                {
                    if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                    include('tovar_item.php');
                    $i++;
                }
                ?>
            </div>
        </div>
        
        <div id = "tovar-section-header">
            <span class = "big-text">Новинки в нашем магазине</span>
        </div>

        <div class = "tovar-container">
            <?php
            $zapros_tovar = "SELECT * FROM tovar ORDER BY id desc LIMIT 4";
            $result_tovar = $mybase -> query($zapros_tovar);

            $i = 1;
            ?>
            <div class = "tovar-row">
                <?php
                while ($tovar = $result_tovar -> fetch_array()) 
                {
                    if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                    include('tovar_item.php');
                    $i++;
                }
                ?>
            </div>
        </div>
        <?php
        }
        else
        {
        ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Результаты поиска</span>
        </div>

        <div class = "tovar-container">
            <?php
            $poisk = str_replace(" ", "%", $_GET['poisk']);
            $zapros_tovar = "SELECT * FROM tovar WHERE name LIKE '%".$poisk."%' ORDER BY name";
            $result_tovar = $mybase -> query($zapros_tovar);
            
            if (!$tovar = $result_tovar -> fetch_array())
            {
            ?>
                <span class = "big-text warning">По вашему запросу ничего не найдено</span>
            <?php
            }
            else
            {
                $i = 1;
                ?>
                <div class = "tovar-row">
                    <?php
                    while ($tovar) 
                    {
                        if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                        include('tovar_item.php');
                        $tovar = $result_tovar -> fetch_array();
                        $i++;
                    }
                    ?>
                </div>
            <?php
            }
            ?>
        </div>
        <?php
        }
    }
    else
    {
        $_SESSION['content'] = "katalog&kat_id=".$_GET['kat_id'];
        $hidden = ($_GET['poisk'])? "" : "hidden";
        $_SESSION['kat_id'] = $_GET['kat_id'];
    ?>
        <form id = "katalog-poisk" method="post" action="kat_poisk_action.php">
            <input class="form-control" type="text" placeholder="Поиск товара по названию" name = "poisk" value="<?=$_GET['poisk']?>">
            <button class="my-btn" type="submit" name = "search">Искать</button>
            <button class="btn-clean" type="submit" name = "clean" <?=$hidden?>><img src="img/icons/trash.svg" alt="Очистить" width = "100%"></button>
        </form>
        
        <div id = "tovar-section-header">
            <span class = "big-text">Рейтинговые товары других категорий</span>
        </div>
        <?php include('karusel.php');?>
        
        <?php
            if (!isset($_GET['poisk']))
            {
        ?>
            <div id = "tovar-section-header">
                <span class = "big-text">Рекомендуем для Вас</span>
            </div>

            <div class = "tovar-container">
                <?php
                $zapros_tovar = "SELECT * FROM tovar WHERE id_kateg = '".$_GET['kat_id']."' ORDER BY rate desc LIMIT 4";
                $result_tovar = $mybase -> query($zapros_tovar);

                $i = 1;
                ?>
                <div class = "tovar-row">
                    <?php
                    while ($tovar = $result_tovar -> fetch_array()) 
                    {
                        if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                        include('tovar_item.php');
                        $i++;
                    }
                    ?>
                </div>
            </div>

            <div id = "tovar-section-header">
                <span class = "big-text">Все товары этой категории</span>
            </div>

            <div class = "tovar-container">
                <?php
                $zapros_tovar = "SELECT * FROM tovar WHERE id_kateg = '".$_GET['kat_id']."' ORDER BY name";
                $result_tovar = $mybase -> query($zapros_tovar);

                $i = 1;
                ?>
                <div class = "tovar-row">
                    <?php
                    while ($tovar = $result_tovar -> fetch_array()) 
                    {
                        if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                        include('tovar_item.php');
                        $i++;
                    }
                    ?>
                </div>
            </div>
        <?php
            }
        else
        {
        ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Результаты поиска</span>
        </div>

        <div class = "tovar-container">
            <?php
            $poisk = str_replace(" ", "%", $_GET['poisk']);
            $zapros_tovar = "SELECT * FROM tovar WHERE (name LIKE '%".$poisk."%') and (id_kateg = '".$_GET['kat_id']."') ORDER BY name";
            $result_tovar = $mybase -> query($zapros_tovar);
            
            if (!$tovar = $result_tovar -> fetch_array())
            {
            ?>
                <span class = "big-text warning">По вашему запросу ничего не найдено</span>
            <?php
            }
            else
            {
                $i = 1;
                ?>
                <div class = "tovar-row">
                    <?php
                    while ($tovar) 
                    {
                        if ($i % 5 == 0) echo '</div><div class = "tovar-row">';
                        include('tovar_item.php');
                        $tovar = $result_tovar -> fetch_array();
                        $i++;
                    }
                    ?>
                </div>
            <?php
            }
            ?>
        </div>
        <?php
        }
    }
    ?>
</div>
