<?php
session_start();
require_once("dbconnect.php");
$temp = "&section=buy";

if (isset($_POST["buy-btn"]))
{
    $i = 0;
    while($i < $_POST["buy-btn"])
    {
        if(isset($_POST["check$i"]))
        {
            $zapros = "UPDATE korzina SET oplacheno = '1' WHERE korzina.id = '".$_POST["check$i"]."'";
            $result = $mybase -> query($zapros);
            
            if (!$result)
            {
                die('Ошибка оплаты товара.'.$mybase->error);
            }
        }
        $i++;
    }
}

if (isset($_POST["del-all-btn"]))
{
    $i = 0;
    while($i < $_POST["del-all-btn"])
    {
        if(isset($_POST["check$i"]))
        {
            $zapros = "DELETE FROM korzina WHERE id = '".$_POST["check$i"]."'";
            $result = $mybase -> query($zapros);
            
            if (!$result)
            {
                die('Ошибка удаления товара из корзины.'.$mybase->error);
            }
        }
        $i++;
    }
}

if (isset($_POST["del-btn"]))
{
    $temp = "&section=bought";
    $zapros = "DELETE FROM korzina WHERE id = '".$_POST["del-btn"]."'";
    $result = $mybase -> query($zapros);
            
    if (!$result)
    {
        die('Ошибка удаления товара из корзины.'.$mybase->error);
    }
}

header("Location: index.php?content=korzina".$temp);
?>