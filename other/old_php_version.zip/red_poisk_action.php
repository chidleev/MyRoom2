<?php
$temp = (empty($_POST['poisk']) or (isset($_POST['clean'])))? "" : "&poisk=".$_POST['poisk'];
header("Location: index.php?content=admin&action=red&object=tovar".$temp);
?>