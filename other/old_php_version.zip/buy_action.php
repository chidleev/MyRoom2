<?php
session_start();
require_once("dbconnect.php");


if($_POST['buy'] and $_SESSION['is_login']) 
{
    $tovar_id = $_POST['buy'];
    $user_id = $_SESSION['user_id'];
    $date = date('Y-m-d');
    
    $zapros = "INSERT INTO korzina(tovar_id, user_id, dobav) VALUES('".$tovar_id."','".$user_id."','".$date."')";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка выполнения запроса на добавление товара в корзину.'.$mybase->error);
    }
}

header("Location: index.php?content=".$_SESSION['content']);
?>