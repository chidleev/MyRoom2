<?php
    $mybase = new mysqli("localhost", "root", "root", "shop");

    if ($mybase -> connect_error)
    {
        print("Не удалось подключиться.");
        exit();
    }
?>