<?php
if ($_SESSION['is_admin'] == true)
{
?>
<div id = "katalog-main-container">
    <div id = "about-text">
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">панель администратора</span>
        
        <form class = "admin-form" action="admin_action.php" method="post">
            <select class="form-control" name = "object" required>
                <option <?=($_GET['object'] == "tovar")? "selected":""?> value = "tovar">Товар</option>
                <option <?=($_GET['object'] == "kategory")? "selected":""?> value = "kategory">Категории</option>
            </select>

            <div id = "profile-btns">
                <input class="my-btn" type="submit" name = "add-btn" value = "Добавление">
                <input class="my-btn" type="submit" name = "red-btn" value = "Редактирование">
            </div>
        </form>
    </div>

    <?php
    if ($_GET['action'] == "add")
    {
        if ($_GET['object'] == "kategory")
        {
        ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Добавить категорию</span>
        </div>

        <form class = "admin-form" action="add_action.php" method="post">
            <div class="form-group">
                <label for="kat-name" class = "medium-text">Название категории</label>
                <input required class="form-control" type="text" name = "kat-name">
                <br>

                <input class="my-btn" type="submit" name = "add_kat" value = "Добавить">
            </div>
        </form>
        <?php
        }
        if ($_GET['object'] == "tovar")
        {
        ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Добавить товар</span>
        </div>

        <form class = "admin-form" action="add_action.php" method="post">
            <div class="form-group">
                <label for="name">Название товара</label>
                <input required class="form-control" type="text" name = "name" id = "name">
                <label for="opis">Описание товара</label>
                <input required class="form-control" type="text" name = "opis" id = "opis">
                <label for="price">Цена товара</label>
                <input required class="form-control" type="number" name = "price" id = "price">
                <label for="garantiya">Гарантия товара</label>
                <input required class="form-control" type="number" name = "garantiya" id = "garantiya">
            </div>

            <div class="form-group">
                <select class="form-control" name = "kategory" required>
                    <option selected disabled value = "">Выберите категорию товара</option>

                    <?php
                    $zapros = "SELECT * FROM kategory";
                    $result = $mybase -> query($zapros);

                    while ($result_row = $result -> fetch_array()) 
                    {
                    ?>
                        <option value="<?=$result_row["id"]?>"><?=$result_row["name"]?></option>
                    <?php 
                    }
                    ?>

                </select>
                <br>

                <label for="foto">Фотография товара</label>
                <input required type="file" class="form-control-file" id="foto" name = "foto" accept="image/jpeg">
                <br>

                <label for="rate">Предварительная оценка товара</label>
                <input class="form-control" type="range" name = "rate" id = "rate" min = "0" max = "1" step="0.01" value = "0.75">
                <br>

                <input class="my-btn" type="submit" name = "add_tovar" value = "Добавить">
            </div>

            <div class="form-group">
                <label for="width">Ширина товара</label>
                <input required class="form-control" type="number" name = "width" id = "width">
                <label for="height">Высота товара</label>
                <input required class="form-control" type="number" name = "height" id = "height">
                <label for="glybina">Глубина товара</label>
                <input required class="form-control" type="number" name = "glybina" id = "glybina">
                <label for="ves">Вес товара</label>
                <input required class="form-control" type="number" name = "ves" id = "ves">
            </div>
        </form>
        <?php
        }
    }
 
 
    if ($_GET['action'] == "red")
    {
        if ($_GET['object'] == "kategory")
        {
        ?>
        <div id = "tovar-section-header">
            <span class = "big-text">Редактировать категорию</span>
        </div>
        
        <form class = "red-admin-form" action="red_action.php" method="post">
            <?php
            $zapros = "SELECT * FROM kategory";
            $result = $mybase -> query($zapros);

            while ($result_row = $result -> fetch_array()) 
            {
            ?>
            <div class = "red-row">
                <input required class="form-control" type="text" name = "name<?=$result_row['id']?>" value = "<?=$result_row['name']?>">

                <div class = "profile-btns">
                    <button class="my-btn" type="submit" name = "red-kat-btn" value = "<?=$result_row['id']?>">Редактировать</button>
                    <button class="my-btn btn-clean" type="submit" name = "del-kat-btn" value = "<?=$result_row['id']?>">Удалить</button>
                </div>
            </div>
            <?php 
            }
            ?>
        </form>
        
        <?php
        }
        if ($_GET['object'] == "tovar")
        {
            $hidden = ($_GET['poisk'])? "" : "hidden";
        ?>
            <div id = "tovar-section-header">
                <span class = "big-text">Редактировать товар</span>
            </div>

            <div class = "red-row">
                <form class = "admin-form" method="post" action="red_poisk_action.php">
                    <input class="form-control" type="text" placeholder="Поиск товара по названию" name = "poisk" value="<?=$_GET['poisk']?>">
                    <button class="my-btn" type="submit" name = "search">Искать</button>
                    <button class="btn-clean" type="submit" name = "clean" <?=$hidden?>><img src="img/icons/trash.svg" alt="Очистить" width = "100%"></button>
                </form>
            </div>

            <form class = "red-admin-form" action="red_action.php" method="post">
                <?php
                $poisk = str_replace(" ", "%", $_GET['poisk']);
                $zapros = "SELECT * FROM tovar WHERE name LIKE '%".$poisk."%' ORDER BY id DESC";
                $result = $mybase -> query($zapros);

                while ($result_row = $result -> fetch_array()) 
                {
                ?>
                <div class = "red-row">
                    <img src="img/tovar/<?=$result_row['foto']?>" alt="Фото товара" height="50px">

                    <input required class="form-control" type="text" name = "name<?=$result_row['id']?>" value = "<?=$result_row['name']?>">

                    <div class = "profile-btns">
                        <button class="my-btn" type="submit" name = "red-tovar-btn" value = "<?=$result_row['id']?>">Редактировать</button>
                        <button class="my-btn btn-clean" type="submit" name = "del-tovar-btn" value = "<?=$result_row['id']?>">Удалить</button>
                    </div>
                </div>
                <?php 
                }
                ?>
            </form>
        <?php
        }
    }
    ?>
</div>
<?php
}
else
{
?>
<div id = "about-main-container">
    <div id = "about-text">
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">панель администратора</span>
    </div>

    <span class = "big-text warning">
        Вы правда думали, что все так просто?))
    </span>

    <a class = "my-btn" href="index.php?content=login" title = "Войти в свой профиль">Войти</a>
</div>
<?php
}
?>