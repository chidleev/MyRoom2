<?php
session_start();
require_once("dbconnect.php");

$login = $_POST['login'];
$pass = $_POST['pass'];
$temp = "login";

if((!empty($login)) && (!empty($pass)))
{
    $zapros = "SELECT * FROM user WHERE login = '".$login."'";
    $result = $mybase -> query($zapros);
    
    if($user_info = $result -> fetch_array())
    {
        if($user_info['pass'] == $pass)
        { 
            $_SESSION['user_id'] = $user_info['id'];
            $_SESSION['user_name'] = $user_info['name'];
            $_SESSION['user_fam'] = $user_info['fam'];
            $_SESSION['user_login'] = NULL;
            $_SESSION['login_mess'] = "";
            
            $_SESSION['is_login'] = true;
            $temp = "user";
            
            if($user_info['admin'] == true)
            {
                $_SESSION['is_admin'] = true;
                $temp = "admin&action=add&object=tovar";
            }
        }
        else
        {
            $_SESSION['login_mess'] = "Неверный пароль!";
            $_SESSION['user_login'] = $user_info['login'];
        }
    }
    else
    {
        $_SESSION['login_mess'] = "Пользователя с таким логином не существует!";
    }
}
else
{
    $_SESSION['login_mess'] = "Вы заполнили не все поля!";
}

header("Location: index.php?content=".$temp);
?>