<?php
if ($_SESSION['is_login'] == true)
{
    $_SESSION['section'] = $_GET['section'];
    $hidden = ($_GET['poisk'])? "" : "hidden";
?>
    <div id = "katalog-main-container">
        <div id = "about-text">
            <span id = "about-text-name">MyRoom</span>
            <span id = "about-text-desc">ваша корзина товаров</span>

            <div id = "profile-btns">
                <a class = "my-btn <?=($_GET['section'] == "buy")? "active-btn":""?>" href="index.php?content=korzina&section=buy">Оплатить</a>
                <a class = "my-btn <?=($_GET['section'] == "bought")? "active-btn":""?>" href="index.php?content=korzina&section=bought">Уже оплачено</a>
            </div>
        </div>
        
        <div class = "red-row">
            <form class = "admin-form" method="post" action="korzina_poisk_action.php">
                <input class="form-control" type="text" placeholder="Поиск товара по названию" name = "poisk" value="<?=$_GET['poisk']?>">
                <button class="my-btn" type="submit" name = "search">Искать</button>
                <button class="btn-clean" type="submit" name = "clean" <?=$hidden?>><img src="img/icons/trash.svg" alt="Очистить" width = "100%"></button>
            </form>
        </div>

        <form class = "red-admin-form" action="korzina_action.php" method="post">
            <?php
            $poisk = str_replace(" ", "%", $_GET['poisk']);
            $zapros = "SELECT *, tovar.id as tovar_id, korzina.id as kor_id FROM korzina JOIN tovar ON korzina.tovar_id = tovar.id WHERE (tovar.name LIKE '%".$poisk."%') and (korzina.user_id = '".$_SESSION['user_id']."') and (korzina.oplacheno = '".(($_GET['section'] == "buy")? "0":"1")."') ORDER BY korzina.id DESC";
            $result = $mybase -> query($zapros);

            $i = 0;
            while ($result_row = $result -> fetch_array()) 
            {
            ?>
            <div class = "red-row">
                <div class = "korzina-name">
                    <img src="img/tovar/<?=$result_row['foto']?>" alt="Фото товара" height="50px">
                    <a class = "tovar-name medium-text" href="index.php?content=tovar&tovar_id=<?=$result_row['tovar_id']?>"><?=$result_row['name']?></a>
                </div>
                
                <div class = "korzina-btns">
                    <span class="medium-text"><?=$result_row['dobav']?></span>
                    <span class="medium-text"><span id = "price<?=$result_row['tovar_id']?>"><?=$result_row['price']?></span> руб.</span>
                    <input onchange="sum()" class = "korzina-chek" type="checkbox" <?=($_GET['section'] == "buy")? "" : "hidden"?> id = "<?=$result_row['tovar_id']?>" name = "check<?=$i?>" value = "<?=$result_row['kor_id']?>">
                    <button class="my-btn btn-clean" type="submit" name = "del-btn" value = "<?=$result_row['kor_id']?>" <?=($_GET['section'] == "buy")? "hidden" : ""?>><img src="img/icons/trash.svg" alt="Очистить" width = "80%"></button>
                </div>
            </div>
            <?php 
            $i++;
            }
            ?>
            
            <div class = "red-row" <?=($_GET['section'] == "buy")? "" : "hidden"?>>
                <span class = "medium-text">Итого к оплате: <span id = "total_sum"></span></span>
                
                <div class = "itog-korzina-btns">
                    <button class="my-btn" type="submit" name = "buy-btn" id = "buy-btn" value = "<?=$i?>">Оплатить выделенное</button>
                    <button class="my-btn btn-clean" type="submit" name = "del-all-btn" value = "<?=$i?>" title = "удалить выделенное"><img src="img/icons/trash.svg" alt="Очистить" width = "80%"></button>
                </div>
            </div>
        </form>
    </div>
<?php
}
else
{
?>
    <div id = "about-main-container">
        <div id = "about-text">
            <span id = "about-text-name">MyRoom</span>
            <span id = "about-text-desc">ваша корзина товаров</span>
        </div>
        
        <span class = "big-text warning">
            Вернитесь на страницу авторизации и введите необходимые данные, чтобы увидеть свои покупки!
        </span>
        
        <a class = "my-btn" href="index.php?content=login" title = "Войти в свой профиль">Войти</a>
    </div>
<?php
}
?>


<script>
    function sum()
    {
        var ch, sum;
        sum = 0;
        ch = document.querySelectorAll("input.korzina-chek");
        ch.forEach(el => (sum +=  (el.checked)? parseFloat(document.getElementById("price"+el.id).innerHTML) : 0));
        document.getElementById("total_sum").innerHTML = sum + " руб.";
    }
    sum();
</script>