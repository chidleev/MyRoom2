<?php
$object = $_POST['object'];
$action = (isset($_POST['add-btn']))? "add" : "red";
header("Location: index.php?content=admin&action=$action&object=$object");
?>