<?php
    $mybase = new mysqli("localhost", "user3333_root", "Root1_Root2-", "user3333_shop");

    if ($mysqli -> connect_error)
    {
        print("Не удалось подключиться.");
        exit();
    }
?>