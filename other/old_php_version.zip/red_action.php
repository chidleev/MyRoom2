<?php
require_once("dbconnect.php");
$temp = "&object=tovar";

if (isset($_POST['red-kat-btn']))
{
    $name = $_POST["name".$_POST['red-kat-btn']];
    $temp = "&object=kategory";
    
    $zapros = "UPDATE kategory SET name = '".$name."' WHERE id = '".$_POST['red-kat-btn']."'";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка обновления информации о категории.'.$mybase -> error);
    }
}

if (isset($_POST['del-kat-btn']))
{
    $temp = "&object=kategory";
    
    $zapros = "DELETE FROM tovar WHERE id_kateg = '".$_POST['del-kat-btn']."'";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка удаления товаров этой категории.'.$mybase -> error);
    }
    
    $zapros = "DELETE FROM kategory WHERE id = '".$_POST['del-kat-btn']."'";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка удаления категории.'.$mybase -> error);
    }
}

if (isset($_POST['red-tovar-btn']))
{
    $name = $_POST["name".$_POST['red-tovar-btn']];
    
    $zapros = "UPDATE tovar SET name = '".$name."' WHERE id = '".$_POST['red-tovar-btn']."'";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка обновления информации о товаре.'.$mybase -> error);
    }
}

if (isset($_POST['del-tovar-btn']))
{
    $zapros = "DELETE FROM tovar WHERE id = '".$_POST['del-tovar-btn']."'";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка удаления товара.'.$mybase -> error);
    }
}

header("Location: index.php?content=admin&action=red".$temp);
?>