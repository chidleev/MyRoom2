<?php 
session_start();
$_SESSION['content'] = "tovar&tovar_id=".$_GET['tovar_id'];
$zapros = "SELECT * FROM tovar WHERE id = '".$_GET['tovar_id']."'";
$result = $mybase -> query($zapros);
$tovar = $result -> fetch_array()
?>
<div id = "katalog-main-container">
    <div id = "about-text">
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">интернет-магазин мебели</span>
    </div>
    
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <span class = "big-text"><?=$tovar['name']?></span>
       
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class = "carousel-item-main">
                    <div class = "carousel-item-border"></div>
                    <div class = "carousel-item-center">
                        <img class = "tovar-foto" src="img/tovar/<?=$tovar['foto']?>" alt="Фото товара" height = "100%">
                    </div>
                    <div class = "carousel-item-border"></div>
                </div>
            </div>
        </div>
        
        <form class = "admin-form" action="buy_action.php" method="post"><button class="my-btn" type="submit" name = "buy" value = "<?=$tovar['id']?>">В корзину</button></form>
    </div>
    
    <div class = "tovar-desc">
        <span class = "medium-text"><?=$tovar['opisanie']?></span>
    </div>
    
    <div class = "tovar-harak">
        <p>
            <span class = "medium-text">Ширина: <?=$tovar['width']?> см.</span>
            <span class = "medium-text">Длина: <?=$tovar['glybina']?> см.</span>
            <span class = "medium-text">Высота: <?=$tovar['height']?> см.</span>
        </p>
        
        <p>
            <span class = "medium-text">Вес: <?=$tovar['ves']?> кг.</span>
            <span class = "medium-text">Рейтинг: <?=$tovar['rate']?></span>
            <span class = "medium-text">Гарантия (лет): <?=(empty($tovar['garantiya']))? "отсутствует" : $tovar['garantiya']?></span>
        </p>
    </div>
</div>