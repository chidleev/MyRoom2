<?php
session_start();
$temp = (empty($_POST['poisk']) or (isset($_POST['clean'])))? "" : "&poisk=".$_POST['poisk'];
header("Location: index.php?content=korzina&section=".$_SESSION['section'].$temp);
?>