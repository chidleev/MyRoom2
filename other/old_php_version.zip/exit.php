<?php
session_start();

$_SESSION['user_id'] = NULL;
$_SESSION['user_name'] = NULL;
$_SESSION['user_fam'] = NULL;
$_SESSION['is_login'] = false;
$_SESSION['is_admin'] = false;

header("Location: index.php?content=profile");
?>