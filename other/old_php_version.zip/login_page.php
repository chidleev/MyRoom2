<div id = "about-main-container">
    <div id = "about-text">
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">интернет-магазин мебели</span>
        <form action="login_action.php" method="post">
            <input required class="form-control" type="text" name = "login" placeholder = "Введите Ваш логин" value = "<?=$_SESSION['user_login']?>">
            <input required class="form-control" type="text" name = "pass" placeholder = "Введите Ваш пароль">
            <br>
            <input class="my-btn" type="submit" name = "login_buttom" value = "Войти">
        </form>
    </div>
    
    <span class = "big-text warning"><?=$_SESSION['login_mess']?></span>

    <span id = "about-text-help">Введите логин и пароль, чтобы войти в свой профиль</span>
</div>