<div class = "tovar-item">
    <div class = "tovar-foto">
        <img src="img/tovar/<?=$tovar['foto']?>" alt="Фото товара" width="100%">
        
        <a class = "tovar-name" href="index.php?content=tovar&tovar_id=<?=$tovar['id']?>">
            <?=$tovar['name']?>
        </a>
        
        <span><?=$tovar['width']?> X <?=$tovar['height']?> X <?=$tovar['glub']?> см. | <?=$tovar['ves']?> кг.</span>
    </div>
    
    
    <div class = "tovar-footer">
        <div class = "rate-row">
           <span>
                Рейтинг: <?=$tovar['rate']?>
            </span>
            
            <div class = "indicator">
                <div class = "indicator" style = "width: <?=$tovar['rate'] * 100?>%">
                </div>
            </div>
        </div>
       
        <span id = "carousel-tovar-price" class="medium-text"><?=$tovar['price']?> руб.</span>
                
        <form class = "admin-form" action="buy_action.php" method="post"><button class="my-btn" type="submit" name = "buy" value = "<?=$tovar['id']?>">В корзину</button></form>
    </div>
</div>