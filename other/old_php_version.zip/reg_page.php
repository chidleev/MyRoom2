<div id = "about-main-container">
    <div id = "about-text">
        <span id = "about-text-name">MyRoom</span>
        <span id = "about-text-desc">интернет-магазин мебели</span>
        <form action="reg_action.php" method="post">
            <input required class="form-control" type="text" name = "fam" placeholder = "Введите Вашу фамилию">
            <input required class="form-control" type="text" name = "name" placeholder = "Введите Ваше имя">
            <input required class="form-control" type="text" name = "login" placeholder = "Введите Ваш логин">
            <input required class="form-control" type="text" name = "pass" placeholder = "Введите Ваш пароль">
            <input required class="form-control" type="email" name = "email" placeholder = "Введите Ваш email">
            <input required class="form-control" type="tel" name = "tel" placeholder = "Введите Ваш номер телефона">
            <br>
            <input required class="my-btn" type="submit" name = "reg_buttom" value = "Зарегистрироваться"><br>
        </form>
    </div>
    
    <span class = "big-text warning"><?=$_SESSION['reg_mess']?></span>

    <span id = "about-text-help">Введите все необходимые данные, чтобы зарегистрировать свой профиль</span>
</div>