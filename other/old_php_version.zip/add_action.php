<?php
session_start();
require_once("dbconnect.php");


if($_POST['add_tovar']) 
{
    $name = $_POST['name'];
    $opis = $_POST['opis'];
    $kat_id = $_POST['kategory'];
    $price = $_POST['price'];
    $rate = $_POST['rate'];
    $width = $_POST['width'];
    $height = $_POST['height'];
    $glybina = $_POST['glybina'];
    $ves = $_POST['ves'];
    $garantiya = $_POST['garantiya'];
    
    $temp = "&action=add&object=tovar";
    
    
    $uploads_dir = $_SESSION['uploads_dir'];
    $tmp_name = $_FILES["foto"]["tmp_name"];
    $pic_name = basename($_FILES["foto"]["name"]);
    $pic_ok = move_uploaded_file($tmp_name, "$uploads_dir/$pic_name");
    
    
    $zapros = "INSERT INTO tovar(name, opisanie, id_kateg, price, foto, rate, width, height, glybina, ves, garantiya) VALUES('".$name."','".$opis."','".$kat_id."','".$price."','".$pic_name."','".$rate."','".$width."','".$height."','".$glybina."','".$ves."','".$garantiya."')";
    $result = $mybase -> query($zapros);

    if (!$result)
    {
        die('Ошибка выполнения запроса на добавление товара.'.$mybase->error);
    }
    
    if (!$pic_ok)
    {
        die('Ошибка загрузки фотографии товара.'.$mybase->error);
    }
    
    
    $zapros = "SELECT MAX(id) as id FROM tovar";
    $result = $mybase -> query($zapros);
    
    if ($result_row = $result -> fetch_array())
    {
        rename("$uploads_dir/$pic_name", "$uploads_dir/$kat_id".'_'.$result_row['id']);
    }
    else
    {
        die('Ошибка переименования фотграфии товара.'.$mybase->error);
    }
    
    
    $zapros = "UPDATE tovar SET foto = '".$kat_id.'_'.$result_row['id']."' WHERE id = '".$result_row['id']."';";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка обновления информации о фотографии товара.'.$mybase->error);
    }
}


if($_POST['add_kat']) 
{
    $kat_name = $_POST['kat-name'];
    $temp = "&action=add&object=kategory";
    
    $zapros = "INSERT INTO kategory(name) VALUES('".$kat_name."')";
    $result = $mybase -> query($zapros);
    
    if (!$result)
    {
        die('Ошибка выполнения запроса на добавление категории.');
    }
}

header("Location: index.php?content=admin".$temp);
?>