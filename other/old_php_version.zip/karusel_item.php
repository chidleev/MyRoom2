<?php
$tovar_zapros = "SELECT * FROM tovar WHERE id_kateg = '".$kategory['id']."' ORDER BY rate DESC LIMIT 1";
$tovar_result = $mybase -> query($tovar_zapros);
$tovar = $tovar_result -> fetch_array();
?>
   

<div class = "carousel-item-main">
    <div class = "carousel-item-border"></div>
    <div class = "carousel-item-center">
        <img src="img/tovar/<?=$tovar['foto']?>" alt="Фото товара" height = "100%">
        
        <div id = "carousel-text">
            <a id = "carousel-tovar-name" href="index.php?content=tovar&tovar_id=<?=$tovar['id']?>" class="medium-text"><span><?=$tovar['name']?></span></a>
            
            <span id = "carousel-tovar-desc"><?=$tovar['opisanie']?></span>
            
            <div id = "carousel-text-footer">
                <span id = "carousel-tovar-price" class="medium-text"><?=$tovar['price']?> руб.</span>
                
                <form action="buy_action.php" method="post"><button class="my-btn" type="submit" name = "buy" value = "<?=$tovar['id']?>">В корзину</button></form>
            </div>
        </div>
    </div>
    <div class = "carousel-item-border"></div>
</div>
