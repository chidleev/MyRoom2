<?php
if ($_SESSION['is_login'] == true)
{
?>
    <div id = "katalog-main-container">
        <div id = "about-text">
            <span id = "about-text-name">MyRoom</span>
            <span id = "about-text-desc">интернет-магазин мебели</span>
        </div>
        
        <span class = "big-text">
            Добро пожаловать, <?=$_SESSION['user_fam']?> <?=$_SESSION['user_name']?>!
        </span>
    </div>
<?php
}
else
{
?>
    <div id = "about-main-container">
        <div id = "about-text">
            <span id = "about-text-name">MyRoom</span>
            <span id = "about-text-desc">интернет-магазин мебели</span>
        </div>
        
        <span class = "big-text warning">
            Вернитесь на страницу авторизации и введите необходимые данные, чтобы увидеть свой профиль!
        </span>
        
        <a class = "my-btn" href="index.php?content=login" title = "Войти в свой профиль">Войти</a>
    </div>
<?php
}
?>