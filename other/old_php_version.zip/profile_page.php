<?php 
session_start();

if($_SESSION['is_login'])
    if($_SESSION['is_admin'])
        include("admin_page.php");
    else
        include("user_page.php");
else
{
?>
    <div id = "about-main-container">
        <div id = "about-text">
            <span id = "about-text-name">MyRoom</span>
            <span id = "about-text-desc">интернет-магазин мебели</span>
            <div id = "profile-btns">
                <a class = "my-btn" href="index.php?content=login" title = "Войти в свой профиль">Войти</a>
                <a class = "my-btn" href="index.php?content=reg" title = "Зарегистрироваться">Зарегистрироваться</a>
            </div>
        </div>

        <span id = "about-text-help">Выберите действие, которое хотели бы совершить</span>
    </div>
<?php
}
?>