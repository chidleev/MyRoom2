<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php
        $temp = (isset($_GET['kat_id']))? " WHERE id != '".$_GET['kat_id']."'" : "";
        $zapros = "SELECT * FROM kategory".$temp;
        $result = $mybase -> query($zapros);
        
        $is_first = true;
        $i = 0;
        while ($result_row = $result -> fetch_array())
        { 
            $class = ($is_first)? "active" : "";
            $is_first = false;
        ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo $i++;?>" class="<?=$class?>"></li>
        <?php 
        } 
        ?>
    </ol>

    <div class="carousel-inner">
        <?php
        $zapros = "SELECT * FROM kategory".$temp;
        $result = $mybase -> query($zapros);
        
        $is_first = true;
        while ($kategory = $result -> fetch_array())
        { 
            $class = ($is_first)? "active" : "";
            $is_first = false;
        ?>
            <div class="carousel-item <?=$class?>">
                <?php include("karusel_item.php");?>
            </div>
        <?php
        }
        ?>
    </div>

    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>